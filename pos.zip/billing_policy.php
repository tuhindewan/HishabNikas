<?php require_once 'partials/header.php'; ?>

	<section class="section section--company">
		<section class="section section--title">
			<div class="shell">
				<h1>Billing Policy</h1>
				<i class="ico ico--arrow-down">
				<a href="#" class="move__down"></a>
				</i>
			</div><!-- /.shell -->
		</section><!-- /.section section-/-title -->

		<main class="main full-width">
			<div class="shell">
				<div class="main__body">
					<div class="content">
						<article class="article article__company">
					

						</article><!-- /.article article__company -->
					</div><!-- /.content -->
				</div><!-- /.main__body -->

			</div><!-- /.shell -->
		</main><!-- /.main -->
	</section><!-- /.section section-/-company -->
<?php require_once 'partials/footer.php'; ?>
